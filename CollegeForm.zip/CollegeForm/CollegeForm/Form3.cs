﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeForm
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int quantity=Convert.ToInt32(textBox1.Text);
            int total=0;

            if (radioButton1.Checked)
            {
                total = quantity * 125;
            }

            else if (radioButton2.Checked)

            {
                total=quantity * 175;
            }
            else if (radioButton3.Checked)
            {
                total = quantity * 250;
            }

            if(textBox2.Text=="TRUEBLUE")
            {
                total = total - (total * 10) / 100;
            }

            textBox3.Text=Convert.ToString(total);




            

        }
    }
}
